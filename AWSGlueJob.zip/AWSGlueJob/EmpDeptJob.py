from pyspark.sql import *
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql.functions import udf
import uuid

if __name__ == "__main__":
    spark = SparkSession    \
    .builder    \
    .master("local[2]") \
    .config('spark.jars', 'lib/postgresql-42.2.18.jar') \
    .appName("EmpDeptJob")  \
    .getOrCreate()

    empInfoSchemaStruct = StructType([
        StructField("employee_id",IntegerType()),
        StructField("first_name",StringType()),
        StructField("last_name",StringType()),
        StructField("salary",StringType()),
        StructField("department_id", IntegerType()),
        StructField("department_name",StringType()),
        StructField("salary_increment",IntegerType())
    ])


    empinfoDF = spark.read.format('csv').option("header","true").schema(empInfoSchemaStruct).load("dataSource/flat_data1.csv")
    print(empinfoDF.printSchema())

    empDF = empinfoDF.withColumnRenamed('employee_id','id').select('id','first_name','last_name','salary','department_id')
    deptDF = empinfoDF.withColumnRenamed('department_id','id').withColumnRenamed('department_name','name').select('id','name','salary_increment')
    print(empDF.show())
    print(deptDF.show())

    empDF.write.format("jdbc").options(url='jdbc:postgresql://localhost:5432/northwind',dbtable='public.Employee',user='postgres',password='postgres',driver='org.postgresql.Driver').mode('overwrite').save()
    deptDF.write.format("jdbc").options(url='jdbc:postgresql://localhost:5432/northwind',dbtable='public.Department',user='postgres',password='postgres',driver='org.postgresql.Driver').mode('overwrite').save()
    print(empDF.printSchema())
    empDF.withColumnRenamed('id','employee_id')
    resultDF = deptDF.join(empDF,deptDF.id == empDF.department_id).drop(deptDF.id).withColumnRenamed('id','employee_id').select('employee_id','salary','salary_increment')
    print(resultDF.show())
    finalDF = resultDF.withColumn('updated_salary',resultDF['salary']+(resultDF['salary']*resultDF['salary_increment']/100)).select('employee_id','updated_salary')

    finalDF.write.format("jdbc").options(url='jdbc:postgresql://localhost:5432/northwind',dbtable='public.updated_salaries',user='postgres',password='postgres',driver='org.postgresql.Driver').mode('overwrite').save()


